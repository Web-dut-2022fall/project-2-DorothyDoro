﻿# 基于Django的实现的一个简单的网站
这是一个Python基于Django的课程设计


## 运行
```python manage.py runserver``` 



